-- John Owens Project 2 4

use northwind;
drop procedure if exists getEmployeesWithAtLeastNOrdersLastMonth;
delimiter $
create procedure getEmployeesWithAtLeastNOrdersLastMonth(out total_employees int, n int)
begin

if n < 0 then
signal sqlstate '45000'
set MESSAGE_TEXT = `n cannot be less than zero`;
end if;

select count(*) over() into total_employees
from employees e
join orders o
on o.EmployeeID = e.EmployeeID
where year(o.OrderDate) = year(now()) and month(o.OrderDate) = month(date_sub((now()), interval 1 month))
group by o.EmployeeID
having count(o.EmployeeID) >= n limit 1;

select e.EmployeeID, e.LastName, e.FirstName, e.Title, count(o.OrderID) as total_orders, count(*) over() as total_employees_last_month
from employees e
join orders o
on o.EmployeeID = e.EmployeeID
where year(o.OrderDate) = year(now()) and month(o.OrderDate) = month(date_sub((now()), interval 1 month))
group by o.EmployeeID
having count(o.EmployeeID) >= n;



end$
delimiter ;