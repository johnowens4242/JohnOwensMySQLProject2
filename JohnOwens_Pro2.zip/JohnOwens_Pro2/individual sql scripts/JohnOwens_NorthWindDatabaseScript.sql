-- script to create a northwind database
DROP SCHEMA IF EXISTS `northwind` ;

CREATE SCHEMA IF NOT EXISTS `northwind`;
USE `northwind` ;