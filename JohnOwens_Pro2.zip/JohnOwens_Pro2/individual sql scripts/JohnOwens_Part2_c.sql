-- John Owens Project 2 2-c

use northwind;
drop procedure if exists insertCustomerOrder;
delimiter $
create procedure insertCustomerOrder(customerID varchar(10), employeeID int(11), productID int(11), quantity smallint(6), orderDate datetime, requiredDate datetime, discout float(24, 0))
begin

if quantity > (select p.UnitsInStock from products p where p.productID = productID) then
signal sqlstate '45000'
set MESSAGE_TEXT = `There is not enough product in stock to fulfil that order.`;
end if;

if orderDate > requiredDate then
signal sqlstate '45000'
set MESSAGE_TEXT = `The order date cannot be after the required date.`;
end if;

insert into orders (CustomerID, EmployeeID, OrderDate, RequiredDate, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry)
select customerID, employeeID, orderDate, requiredDate, c.CompanyName, c.Address, c.City, c.Region, c.PostalCode, c.Country
from products p
join customers c
on c.CustomerID = customerID
where p.productID = productID;

insert into `order details` (OrderID, ProductID, Quantity, Discount)
values (LAST_INSERT_ID(), productID, quantity, discount);

update products p
set p.UnitsInStock = p.UnitsInStock - quantity
where p.ProductID = productID;

call addUnitPrice();

end$
delimiter ;