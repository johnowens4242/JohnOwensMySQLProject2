-- John Owens Project 2 1-a

use northwind;

alter table orders
add constraint fk_orders_shippers_ShipperID
foreign key (ShipVia)
references shippers(ShipperID);

alter table orders
add constraint fk_orders_customers_CustomerID
foreign key (CustomerID)
references customers(CustomerID);

alter table orders
add constraint fk_orders_employees_EmployeeID
foreign key (EmployeeID)
references employees(EmployeeID);

alter table `order details`
add constraint fk_order_details_products_ProductID
foreign key (ProductID)
references products(ProductID);

alter table `order details`
add constraint fk_order_details_orders_OrderID
foreign key (OrderID)
references orders(OrderID);

alter table products
add constraint fk_products_categories_CategoryID
foreign key (CategoryID)
references categories(CategoryID);

alter table products
add constraint fk_products_suppliers_SupplierID
foreign key (SupplierID)
references suppliers(SupplierID);