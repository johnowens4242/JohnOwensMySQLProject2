-- John Owens Project 2 2-b

use northwind;
drop procedure if exists addUnitPrice;
delimiter $
create procedure addUnitPrice()
begin

update `order details` od
inner join orders o
on o.OrderID = od.OrderID
inner join productunitpricehistory p
on od.productID = p.productID
set od.unitPrice = p.unitPrice
where o.OrderDate <= p.effectiveDate;

end$
delimiter ;