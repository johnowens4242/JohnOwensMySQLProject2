-- John Owens Project 2 4 procedure call

use northwind;
call getEmployeesWithAtLeastNOrdersLastMonth(@total, 2);
select @total;