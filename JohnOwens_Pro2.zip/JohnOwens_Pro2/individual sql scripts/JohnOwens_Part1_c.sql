-- John Owens Project 2 1-c

use northwind;
drop procedure if exists addCustomerEmail;
delimiter $
create procedure addCustomerEmail()
begin

update customers c
set c.emailaddress = concat(replace(ContactName, ' ', ''), '@', replace ((replace(CompanyName, ' ', '')), '.', ''), '.com');

end$
delimiter ;