-- John Owens Project 2 2-b procedure call

use northwind;
call addUnitPrice();