-- John Owens Project 2 5

use northwind;
drop procedure if exists getPopularCategoryDateRange;
delimiter $
create procedure getPopularCategoryDateRange(initial_date date, ending_date date)
begin

if initial_date > ending_dateaddCustomerEmailaddUnitPrice then
signal sqlstate '45000'
set MESSAGE_TEXT = `the start date cannot be after the final date`;
end if;

select c.CategoryName, s.CompanyName, sum(((od.UnitPrice) * (od.Quantity)) - (((od.UnitPrice) * (od.Quantity)) * discount)) as total_dollar_amount, count(distinct o.OrderID) as total_orders
from categories c
join products p
on c.CategoryID = p.CategoryID
join suppliers s
on p.SupplierID = s.SupplierID
join `order details` od
on od.ProductID = p.ProductID
join orders o
on o.OrderID = od.OrderID
where o.OrderDate >= initial_date and o.OrderDate <= ending_date
group by c.CategoryID, s.SupplierID
order by c.CategoryName, s.CompanyName;

end$
delimiter ;