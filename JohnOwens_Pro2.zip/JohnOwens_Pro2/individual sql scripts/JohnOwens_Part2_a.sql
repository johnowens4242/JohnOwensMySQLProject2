-- John Owens Project 2 2-a

use northwind;

ALTER TABLE `order details`
ADD COLUMN unitPrice decimal(10, 2);