-- John Owens Project 2 5 procedure call

use northwind;
call getPopularCategoryDateRange('1996-07-01', '1996-07-31');