-- John Owens Project 2 1-c procedure call

use northwind;
call addCustomerEmail();
