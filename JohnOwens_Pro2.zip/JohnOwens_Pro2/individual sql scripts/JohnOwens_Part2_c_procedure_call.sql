-- John Owens Project 2 2-c procedure call

use northwind;
call insertCustomerOrder('ALFKI', 4, 33, 112, "1996-07-05 00:00:00", "1996-08-16 00:00:00", 0.05);

call insertCustomerOrder('QUEDE', 5, 4, 54, "1996-07-05 00:00:00", "1996-08-16 00:00:00", 0.05);