-- John Owens Project 2 1-b

use northwind;

ALTER TABLE customers
ADD COLUMN emailaddress varchar(100);