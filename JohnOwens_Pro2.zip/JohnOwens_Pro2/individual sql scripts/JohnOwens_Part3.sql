-- John Owens Project 2 3

use northwind;
drop procedure if exists getPreviousSpendingOfTop5Customer;
delimiter $
create procedure getPreviousSpendingOfTop5Customer(spending_year year, number_of_orders int)
begin

if number_of_orders <= 0 then
signal sqlstate '45000'
set MESSAGE_TEXT = `the number of orders must be greater than zero`;
end if;

select * from 
(select c.CustomerID as top_five_customers, c.CompanyName, 

(select count(distinct o.OrderID)
from customers c
join orders o
on c.CustomerID = o.CustomerID
where year(o.OrderDate) = year(date_sub(concat(spending_year, "-01-01"), interval 1 year)) and c.CustomerID = top_five_customers) as previous_year_orders,

(select sum(((od.UnitPrice) * (od.Quantity)) - (((od.UnitPrice) * (od.Quantity)) * discount)) as previous_year_spending
from customers c
join orders o
on c.CustomerID = o.CustomerID
join `order details` od
on od.OrderID = o.OrderID
where year(o.OrderDate) = year(date_sub(concat(spending_year, "-01-01"), interval 1 year)) and c.CustomerID = top_five_customers) as previous_year_spending,

count(distinct o.OrderID) as given_year_orders, sum(((od.UnitPrice) * (od.Quantity)) - (((od.UnitPrice) * (od.Quantity)) * discount)) as given_year_spending
from customers c
join orders o
on c.CustomerID = o.CustomerID
join `order details` od
on od.OrderID = o.OrderID
where year(o.OrderDate) = spending_year
group by c.CustomerID
having count(distinct o.OrderID) >= number_of_orders
order by given_year_spending desc limit 5) as results
order by results.previous_year_spending desc;

end$
delimiter ;