-- John Owens Project 2 3 procedure call

use northwind;
call getPreviousSpendingOfTop5Customer("1997", 4);